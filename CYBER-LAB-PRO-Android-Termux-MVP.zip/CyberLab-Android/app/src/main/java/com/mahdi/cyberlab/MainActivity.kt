package com.mahdi.cyberlab

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import java.util.regex.Pattern

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 14, 20)
    private val panel = Color.rgb(21, 29, 40)
    private val accent = Color.rgb(58, 220, 190)
    private lateinit var hostInput: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
            layoutParams = ViewGroup.LayoutParams(-1, -2)
        }
        scroll.addView(page)
        val brand = TextView(this).apply {
            text = "CYBER LAB PRO"
            textSize = 27f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(brand)
        page.addView(text("Powered by Mahdi  •  Android + Termux", 13, Color.LTGRAY))
        page.addView(space(20))
        page.addView(text("لوحة الأدوات", 20, Color.WHITE, true))
        page.addView(text("شغّل أدوات المختبر من واجهة واحدة. يجب تثبيت Termux وNmap أولاً.", 14, Color.LTGRAY))
        page.addView(space(14))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        page.addView(card, matchWrap())
        card.addView(text("Nmap — فحص أساسي", 18, Color.WHITE, true))
        card.addView(text("أدخل عنوان جهاز تملكه أو مختبرًا مصرحًا لك بفحصه.", 13, Color.LTGRAY))
        hostInput = EditText(this).apply {
            hint = "مثال: 192.168.1.10 أو scanme.nmap.org"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(32, 42, 55))
        }
        card.addView(hostInput, matchWrap().apply { topMargin = dp(12) })
        card.addView(space(10))
        card.addView(actionButton("تشغيل فحص Nmap") { runNmap() })
        card.addView(space(8))
        card.addView(actionButton("فحص اتصال Termux") { runTermuxCheck() })
        page.addView(space(14))
        status = text("الحالة: بانتظار التشغيل", 14, accent, true)
        page.addView(status)
        page.addView(space(8))
        output = TextView(this).apply {
            text = "النتائج ستظهر في طرفية Termux عند تشغيل الأمر."
            textSize = 13f
            setTextColor(Color.rgb(220, 226, 234))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(15, 20, 28))
            typeface = Typeface.MONOSPACE
        }
        page.addView(output, matchWrap())
        page.addView(space(18))
        page.addView(text("الأدوات التالية: DNS / RDAP / بصمات SHA-256 / محلل سجلات / مختبرات تعليمية.", 13, Color.LTGRAY))
        page.addView(space(12))
        page.addView(text("ملاحظة: هذا إصدار أولي يربط التطبيق بأوامر محددة فقط؛ لا ينفذ نصوصًا عشوائية من المستخدم.", 12, Color.GRAY))
        setContentView(scroll)
    }

    private fun runNmap() {
        val host = hostInput.text.toString().trim()
        if (!validHost(host)) {
            status.text = "الحالة: عنوان غير صالح"
            output.text = "أدخل IPv4 أو اسم نطاق صالحًا (من دون مسافات أو خيارات أو أوامر)."
            return
        }
        dispatchTermux(
            "/data/data/com.termux/files/usr/bin/nmap",
            arrayOf("-F", "--", host),
            "طلب فحص Nmap: $host"
        )
    }

    private fun runTermuxCheck() {
        dispatchTermux(
            "/data/data/com.termux/files/usr/bin/bash",
            arrayOf("-lc", "command -v nmap; nmap --version | head -n 2"),
            "فحص تثبيت Nmap"
        )
    }

    private fun dispatchTermux(path: String, args: Array<String>, description: String) {
        val intent = Intent("com.termux.RUN_COMMAND").apply {
            setClassName("com.termux", "com.termux.app.RunCommandService")
            putExtra("com.termux.RUN_COMMAND_PATH", path)
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args)
            putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
        }
        try {
            startService(intent)
            status.text = "الحالة: تم إرسال المهمة إلى Termux"
            output.text = "$description\n\nستفتح طرفية Termux لعرض التنفيذ. إذا لم يحدث شيء، راجع إعداد RUN_COMMAND في README."
        } catch (e: Exception) {
            status.text = "الحالة: تعذّر الاتصال"
            output.text = "تأكد من تثبيت تطبيق Termux الرسمي، ثم فعّل السماح بتنفيذ الأوامر الخارجية في إعداداته وأعد فتح التطبيق.\n\nتفاصيل: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}"
        }
    }

    private fun validHost(value: String): Boolean {
        if (value.isBlank() || value.length > 253 || value.startsWith("-")) return false
        if (value.any { it.isWhitespace() || it == ';' || it == '&' || it == '|' || it == '$' || it == '`' || it == '/' || it == '\\' }) return false
        val ipv4 = Pattern.matches("^(25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})(\\.(25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})){3}$", value)
        val domain = Pattern.matches("(?i)^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}$", value)
        return ipv4 || domain
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.BLACK)
        setBackgroundColor(accent)
        setOnClickListener { action() }
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
