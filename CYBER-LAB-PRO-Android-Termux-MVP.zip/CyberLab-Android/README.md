# CYBER LAB PRO — Android + Termux bridge (MVP)

واجهة Android أصلية أولية لتشغيل أوامر محددة في Termux. هذه نسخة MVP وليست دمجًا داخليًا لأدوات Linux؛ Termux هو محرك التنفيذ.

## المتطلبات
- Android 8 أو أحدث.
- Termux من مصدر موثوق، ويفضّل F-Droid أو صفحة Termux الرسمية على GitHub. لا تخلط تثبيتات من مصادر مختلفة.
- Nmap مثبت داخل Termux.

## إعداد Termux
افتح Termux ونفّذ:
```sh
pkg update
pkg install nmap
```
ثم افتح Termux: Settings > Termux > Allow external apps (قد يختلف الاسم حسب الإصدار). وافق على تشغيل الأوامر الخارجية عند ظهور الطلب.

## بناء APK
ارفع محتويات المشروع إلى مستودع GitHub. افتح Actions ثم `Build Android APK` وشغّل workflow أو انتظر انتهاءه بعد push. نزّل artifact باسم `cyber-lab-pro-debug-apk` ثم استخرج `app-debug.apk` وثبّته على هاتفك.

## ملاحظات الربط
- التطبيق يستخدم `com.termux.RUN_COMMAND` وخدمة `com.termux.app.RunCommandService`.
- يرسل Nmap فحصًا سريعًا للمنافذ الشائعة (`-F`) لعنوان IPv4 أو نطاق صالح.
- قد تختلف سلوكيات التشغيل الخارجي حسب إصدار Termux وإعداداته. إذا لم يعمل، راجع إعداد السماح بالأوامر الخارجية وسجلات التطبيق.
- هذه النسخة تعرض حالة الإرسال داخل التطبيق، بينما مخرجات Nmap تظهر في طرفية Termux. إرجاع stdout داخل التطبيق يحتاج قناة نتائج منفصلة؛ هذه الميزة غير مدعاة هنا.
- لا يوجد تنفيذ لأوامر shell حرة من مربع إدخال؛ يتم تمرير عنوان الهدف كوسيط منفصل بعد التحقق من صيغته.
