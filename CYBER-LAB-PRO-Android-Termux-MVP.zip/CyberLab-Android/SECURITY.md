# Security Notes

- Do not enter targets you do not own or have explicit authorization to test.
- The app does not accept arbitrary shell commands.
- Host input is validated and passed as a separate argument.
- Debug APKs are unsigned for release distribution; sign a release build before publishing.
- Termux integration requires enabling external command execution. Keep that capability limited to trusted apps.
